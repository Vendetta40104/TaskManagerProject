import tkinter as tk
from tkinter import messagebox
import json
import os

TASKS_FILE = "tasks.json"

def load_tasks():
    if not os.path.exists(TASKS_FILE):
        return []
    with open(TASKS_FILE, "r") as f:
        return json.load(f)

def save_tasks(tasks):
    with open(TASKS_FILE, "w") as f:
        json.dump(tasks, f, indent=4)

class TaskManagerApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Task Manager")

        self.tasks = load_tasks()

        # Entry fields
        self.title_entry = tk.Entry(root, width=30)
        self.title_entry.grid(row=0, column=1, padx=5, pady=5)
        tk.Label(root, text="Task Title:").grid(row=0, column=0, sticky="e")

        self.due_entry = tk.Entry(root, width=30)
        self.due_entry.grid(row=1, column=1, padx=5, pady=5)
        tk.Label(root, text="Due Date (YYYY-MM-DD):").grid(row=1, column=0, sticky="e")

        self.priority_entry = tk.Entry(root, width=30)
        self.priority_entry.grid(row=2, column=1, padx=5, pady=5)
        tk.Label(root, text="Priority (1-5):").grid(row=2, column=0, sticky="e")

        # Buttons
        tk.Button(root, text="Add Task", command=self.add_task).grid(row=3, column=1, sticky="ew", padx=5, pady=5)
        tk.Button(root, text="Delete Task", command=self.delete_task).grid(row=4, column=1, sticky="ew", padx=5, pady=5)
        tk.Button(root, text="Mark as Completed", command=self.mark_completed).grid(row=5, column=1, sticky="ew", padx=5, pady=5)

        # Task list
        self.task_listbox = tk.Listbox(root, width=80, height=10)
        self.task_listbox.grid(row=6, column=0, columnspan=2, padx=5, pady=10)

        self.refresh_task_list()

    def add_task(self):
        title = self.title_entry.get()
        due = self.due_entry.get()
        priority = self.priority_entry.get()

        if not title or not due or not priority:
            messagebox.showwarning("Missing Information", "Please fill all fields.")
            return

        try:
            priority = int(priority)
            if not 1 <= priority <= 5:
                raise ValueError
        except ValueError:
            messagebox.showerror("Invalid Priority", "Priority must be a number between 1 and 5.")
            return

        task = {
            "title": title,
            "due_date": due,
            "priority": priority,
            "completed": False
        }
        self.tasks.append(task)
        save_tasks(self.tasks)
        self.refresh_task_list()
        self.title_entry.delete(0, tk.END)
        self.due_entry.delete(0, tk.END)
        self.priority_entry.delete(0, tk.END)

    def delete_task(self):
        selection = self.task_listbox.curselection()
        if not selection:
            messagebox.showwarning("No Selection", "Please select a task to delete.")
            return
        index = selection[0]
        self.tasks.pop(index)
        save_tasks(self.tasks)
        self.refresh_task_list()

    def mark_completed(self):
        selection = self.task_listbox.curselection()
        if not selection:
            messagebox.showwarning("No Selection", "Please select a task to mark as completed.")
            return
        index = selection[0]
        self.tasks[index]["completed"] = True
        save_tasks(self.tasks)
        self.refresh_task_list()

    def refresh_task_list(self):
        self.task_listbox.delete(0, tk.END)
        for task in self.tasks:
            status = "✅" if task["completed"] else "❌"
            display = f"{status} {task['title']} - Due: {task['due_date']} - Priority: {task['priority']}"
            self.task_listbox.insert(tk.END, display)

if __name__ == "__main__":
    root = tk.Tk()
    app = TaskManagerApp(root)
    root.mainloop()